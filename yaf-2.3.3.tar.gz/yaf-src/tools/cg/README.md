##Yaf Codes Generator

###Usage
```
php yaf_cg Sample
```

will generator folder "Sample" under output:
```
$ ls output/Sample/
application/  conf/  index.php  readme.txt
```
